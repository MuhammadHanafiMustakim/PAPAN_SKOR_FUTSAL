// Created by http://oleddisplay.squix.ch/ Consider a donation
// In case of problems make sure that you are using the font file with the correct version!
const uint8_t DejaVu_Sans_9Bitmaps[] PROGMEM = {

	// Bitmap Data:
	0x00, // ' '
	0xFA, // '!'
	0xB4, // '"'
	0x28,0xAF,0xCA,0xFD,0x45,0x00, // '